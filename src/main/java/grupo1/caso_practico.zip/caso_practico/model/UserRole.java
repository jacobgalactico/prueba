package grupo1.caso_practico.model;


public enum UserRole {

    ADMIN,
    SECUTIRY,
    MAINTENANCE

}
