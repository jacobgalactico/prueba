package grupo1.caso_practico.model;


public enum EventType {

    MOTION,
    INTRUSION,
    TEMPERATURE_CHANGE,
    ACCESS_GRANTED,
    ACCESS_DENIED

}
