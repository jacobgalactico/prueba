package grupo1.caso_practico.model;


public enum NotificationStatus {

    SENT,
    NOT_SENT

}
