package grupo1.caso_practico.model;


public enum NotificationType {

    WEBSOCKET,
    EMAIL,
    SMS

}
