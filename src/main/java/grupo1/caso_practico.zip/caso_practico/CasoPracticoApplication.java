package grupo1.caso_practico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CasoPracticoApplication {

    public static void main(final String[] args) {
        SpringApplication.run(CasoPracticoApplication.class, args);
    }

}
